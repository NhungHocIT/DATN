package com.example.GoalMaster.exception;

public enum Error {
}

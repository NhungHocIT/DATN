package com.example.GoalMaster.dto.request;

public class FileInfoUploadRequestDTO {
    Long id;
    String src;
    String fileName;
}

